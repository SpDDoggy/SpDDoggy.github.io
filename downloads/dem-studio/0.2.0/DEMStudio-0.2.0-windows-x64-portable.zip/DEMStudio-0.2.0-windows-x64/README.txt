DEMStudio 0.2.0

运行 DEMStudio.exe。
需要 Microsoft Edge WebView2 Runtime 和支持 OpenGL 3.3 Compatibility Profile 的显卡驱动。

https://github.com/SpDDoggy/DEMStudio/releases/tag/v0.2.0
