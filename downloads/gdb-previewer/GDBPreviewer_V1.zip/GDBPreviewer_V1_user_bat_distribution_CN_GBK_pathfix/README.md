# GDB Previewer V1

轻量级 `.gdb` 快速预览器。

## 安装

双击：

```text
install.bat
```

安装后支持：

- 双击 `.gdb` 文件夹打开 GDB Previewer
- 右键 `.gdb` 文件夹：`用GDB Previewer打开`

## 卸载

双击：

```text
uninstall.bat
```

## 说明

- 当前为用户级安装，不需要管理员权限。
- 安装位置：`%LocalAppData%\Programs\GDBPreviewer`
- 不启用 Preview Pane，不注册 COM Handler，不接管 `.gdb` 文件夹图标。
- `app/` 和 `_internal/` 是运行与安装所需文件，不建议删除或移动。


## 说明

安装与卸载入口已使用中文提示语。


## V1 CN_GBK pathfix

本包修复了中文 bat 分发包在带空格路径下向 PowerShell 传递包根目录时可能出现的“路径中具有非法字符”问题。
