Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$Version = 'V1'
$InstallDir = Join-Path $env:LOCALAPPDATA 'Programs\GDBPreviewer'
$LogPath = Join-Path $env:TEMP 'GDBPreviewer_uninstall.log'

$GdbVerb = 'GdbPreviewer'
$GdbProgId = 'GDBPreviewer.FileGeodatabase'
$LegacyProgId = 'ESRI.GDB.Database'
$StateRoot = 'Software\GDB Previewer'
$BackupRoot = 'Software\GDB Previewer\Backup'
$DoubleClickVerb = 'GdbDoubleClickRouter'
$PreviewHandlerIid = '{8895b1c6-b41f-4c1c-a562-0d564250836f}'
$IExtractIconIid = '{000214FA-0000-0000-C000-000000000046}'

function Write-Log {
    param([string]$Level, [string]$Message)
    $line = '[{0}] {1}' -f $Level, $Message
    Write-Host $line
    $stamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'
    Add-Content -LiteralPath $LogPath -Value ('[{0}] [{1}] {2}' -f $stamp, $Level, $Message) -Encoding UTF8
}

function Write-Step { param([string]$Message); Write-Host ''; Write-Log 'STEP' $Message }

function Set-RegValue {
    param([Microsoft.Win32.RegistryKey]$Root, [string]$SubKey, [string]$Name, [string]$Value)
    $k = $Root.CreateSubKey($SubKey)
    try { $k.SetValue($Name, [string]$Value, [Microsoft.Win32.RegistryValueKind]::String) }
    finally { if ($k) { $k.Close() } }
}

function Remove-RegTreeSafe { param([Microsoft.Win32.RegistryKey]$Root, [string]$SubKey); try { $Root.DeleteSubKeyTree($SubKey, $false) } catch { } }
function Remove-RegValueSafe {
    param([Microsoft.Win32.RegistryKey]$Root, [string]$SubKey, [string]$Name)
    $k = $Root.OpenSubKey($SubKey, $true)
    if ($k) { try { $k.DeleteValue($Name, $false) } finally { $k.Close() } }
}

function Get-RegValueInfo {
    param([Microsoft.Win32.RegistryKey]$Root, [string]$SubKey, [string]$Name)
    $result = @{ KeyExists=$false; ValueExists=$false; Value=$null; Kind='' }
    $k = $Root.OpenSubKey($SubKey, $false)
    if ($k) {
        try {
            $result.KeyExists = $true
            $names = @($k.GetValueNames())
            if ($names -contains $Name) {
                $result.ValueExists = $true
                $result.Value = $k.GetValue($Name, $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
                try { $result.Kind = [string]$k.GetValueKind($Name) } catch { $result.Kind = '' }
            }
        }
        finally { $k.Close() }
    }
    return $result
}

function Get-BackupValue {
    param([string]$Name, [string]$DefaultValue)
    $k = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($BackupRoot, $false)
    if (-not $k) { return $DefaultValue }
    try { $v = $k.GetValue($Name, $null); if ($null -eq $v) { return $DefaultValue }; return [string]$v }
    finally { $k.Close() }
}

function Restore-BackupRegValueIfOurs {
    param([string]$Id,[Microsoft.Win32.RegistryKey]$Root,[string]$SubKey,[string]$Name,[string]$OurExpectedValue)
    $current = Get-RegValueInfo -Root $Root -SubKey $SubKey -Name $Name
    if (-not $current.ValueExists) { Write-Log 'INFO' ('Skip restore: value already absent: {0}\{1}' -f $SubKey, $Name); return }
    if ([string]$current.Value -ne $OurExpectedValue) { Write-Log 'WARN' ('Skip restore because current value no longer belongs to GDB Previewer: {0}\{1}' -f $SubKey, $Name); return }
    $exists = Get-BackupValue -Name ($Id + '_Exists') -DefaultValue '0'
    $value = Get-BackupValue -Name ($Id + '_Value') -DefaultValue ''
    if ($exists -eq '1') { Set-RegValue -Root $Root -SubKey $SubKey -Name $Name -Value $value; Write-Log 'OK' ('Restored registry value: {0}\{1}' -f $SubKey, $Name) }
    else { Remove-RegValueSafe -Root $Root -SubKey $SubKey -Name $Name; Write-Log 'OK' ('Removed GDB Previewer registry value: {0}\{1}' -f $SubKey, $Name) }
}

function Refresh-Shell {
    Write-Step 'Refresh Shell cache'
    $ie4 = Join-Path $env:windir 'System32\ie4uinit.exe'
    if (Test-Path -LiteralPath $ie4) {
        try { Start-Process -FilePath $ie4 -ArgumentList '-ClearIconCache' -Wait -WindowStyle Hidden -ErrorAction SilentlyContinue | Out-Null } catch { }
        try { Start-Process -FilePath $ie4 -ArgumentList '-show' -Wait -WindowStyle Hidden -ErrorAction SilentlyContinue | Out-Null } catch { }
    }
    try {
        Add-Type -Namespace Win32 -Name ShellNotify -MemberDefinition '[System.Runtime.InteropServices.DllImport("shell32.dll")] public static extern void SHChangeNotify(int wEventId, uint uFlags, System.IntPtr dwItem1, System.IntPtr dwItem2);' -ErrorAction SilentlyContinue
        [Win32.ShellNotify]::SHChangeNotify(0x08000000, 0, [IntPtr]::Zero, [IntPtr]::Zero)
    } catch { }
    Write-Log 'OK' 'Shell refresh requested.'
}

function Test-SubKeyOwnedByGdbPreviewer {
    param([string]$SubKey)
    $info = Get-RegValueInfo -Root ([Microsoft.Win32.Registry]::CurrentUser) -SubKey $SubKey -Name 'GDBPreviewerOwner'
    return ($info.ValueExists -and ([string]$info.Value -eq '1'))
}

function Remove-DirectoryVerbIfOurs {
    Write-Step 'Remove .gdb directory context menu if owned by GDB Previewer'
    $verbKey = 'Software\Classes\Directory\shell\' + $GdbVerb
    $owned = Test-SubKeyOwnedByGdbPreviewer -SubKey $verbKey
    $command = Get-RegValueInfo -Root ([Microsoft.Win32.Registry]::CurrentUser) -SubKey ($verbKey + '\command') -Name ''
    if ((-not $owned) -and $command.ValueExists -and ([string]$command.Value -like '*GdbFolderRouter.vbs*')) { $owned = $true }
    if ($owned) { Remove-RegTreeSafe ([Microsoft.Win32.Registry]::CurrentUser) $verbKey; Write-Log 'OK' 'Removed Directory context menu verb.' }
    else { Write-Log 'INFO' 'Directory context menu verb was not owned by GDB Previewer; skipped.' }
}

function Remove-ProgIdIfOurs {
    Write-Step 'Remove GDB Previewer ProgID if owned by GDB Previewer'
    $progKey = 'Software\Classes\' + $GdbProgId
    $owned = Test-SubKeyOwnedByGdbPreviewer -SubKey $progKey
    $command = Get-RegValueInfo -Root ([Microsoft.Win32.Registry]::CurrentUser) -SubKey ($progKey + '\shell\open\command') -Name ''
    if ((-not $owned) -and $command.ValueExists -and ([string]$command.Value -like '*GDBPreviewer.exe*')) { $owned = $true }
    if ($owned) { Remove-RegTreeSafe ([Microsoft.Win32.Registry]::CurrentUser) $progKey; Write-Log 'OK' 'Removed GDB Previewer ProgID.' }
    else { Write-Log 'INFO' 'ProgID was not owned by GDB Previewer; skipped.' }
}

function Restore-DotGdbAssociation {
    Write-Step 'Restore previous .gdb association safely'
    $backupComplete = Get-BackupValue -Name 'BackupComplete' -DefaultValue '0'
    if ($backupComplete -ne '1') { Write-Log 'WARN' 'No registry backup found. Falling back to conservative cleanup only.' }
    Restore-BackupRegValueIfOurs -Id 'DotGdb_Default' -Root ([Microsoft.Win32.Registry]::CurrentUser) -SubKey 'Software\Classes\.gdb' -Name '' -OurExpectedValue $GdbProgId
    Restore-BackupRegValueIfOurs -Id 'DotGdb_PerceivedType' -Root ([Microsoft.Win32.Registry]::CurrentUser) -SubKey 'Software\Classes\.gdb' -Name 'PerceivedType' -OurExpectedValue 'document'
    Restore-BackupRegValueIfOurs -Id 'DotGdb_ContentType' -Root ([Microsoft.Win32.Registry]::CurrentUser) -SubKey 'Software\Classes\.gdb' -Name 'Content Type' -OurExpectedValue 'application/x-filegdb'
    Restore-BackupRegValueIfOurs -Id 'DotGdb_AlwaysShowExt' -Root ([Microsoft.Win32.Registry]::CurrentUser) -SubKey 'Software\Classes\.gdb' -Name 'AlwaysShowExt' -OurExpectedValue ''
    Remove-RegValueSafe ([Microsoft.Win32.Registry]::CurrentUser) 'Software\Classes\.gdb\OpenWithProgids' $GdbProgId
    Write-Log 'OK' 'OpenWithProgids cleanup completed.'
}

function Cleanup-LegacyUserRegistry {
    Write-Step 'Remove legacy user-level Preview Pane / icon hooks if present'
    Remove-RegTreeSafe ([Microsoft.Win32.Registry]::CurrentUser) ('Software\Classes\Directory\ShellEx\' + $PreviewHandlerIid)
    Remove-RegTreeSafe ([Microsoft.Win32.Registry]::CurrentUser) ('Software\Classes\.gdb\ShellEx\' + $PreviewHandlerIid)
    Remove-RegTreeSafe ([Microsoft.Win32.Registry]::CurrentUser) ('Software\Classes\' + $LegacyProgId + '\ShellEx\' + $PreviewHandlerIid)
    Remove-RegTreeSafe ([Microsoft.Win32.Registry]::CurrentUser) ('Software\Classes\' + $GdbProgId + '\ShellEx\' + $PreviewHandlerIid)
    Remove-RegTreeSafe ([Microsoft.Win32.Registry]::CurrentUser) ('Software\Classes\Directory\shell\' + $DoubleClickVerb)
    Remove-RegValueSafe ([Microsoft.Win32.Registry]::CurrentUser) ('Software\Classes\Directory\ShellEx\' + $IExtractIconIid) ''
    Remove-RegValueSafe ([Microsoft.Win32.Registry]::CurrentUser) ('Software\Classes\.gdb\ShellEx\' + $IExtractIconIid) ''
    Write-Log 'OK' 'Legacy user-level hooks removed or skipped.'
}

function Remove-OpenOnlyRegistry {
    Write-Step 'Remove open-only registry entries'
    Remove-DirectoryVerbIfOurs
    Remove-ProgIdIfOurs
    Restore-DotGdbAssociation
    Remove-RegTreeSafe ([Microsoft.Win32.Registry]::CurrentUser) ('Software\Classes\' + $LegacyProgId + '\shell\preview')
    Cleanup-LegacyUserRegistry
    Remove-RegTreeSafe ([Microsoft.Win32.Registry]::CurrentUser) $StateRoot
    Write-Log 'OK' 'Open-only registry cleanup completed.'
}

function Remove-InstallDirectory {
    Write-Step 'Remove install directory'
    if (Test-Path -LiteralPath $InstallDir) {
        Remove-Item -LiteralPath $InstallDir -Recurse -Force -ErrorAction SilentlyContinue
        Start-Sleep -Milliseconds 500
        if (Test-Path -LiteralPath $InstallDir) { Write-Log 'WARN' ('Install directory still exists, remove manually if needed: {0}' -f $InstallDir) }
        else { Write-Log 'OK' ('Removed: {0}' -f $InstallDir) }
    } else { Write-Log 'INFO' 'Install directory does not exist.' }
}

try {
    if (Test-Path -LiteralPath $LogPath) { Remove-Item -LiteralPath $LogPath -Force -ErrorAction SilentlyContinue }
    Write-Log 'INFO' ('GDB Previewer uninstaller {0}' -f $Version)
    Write-Log 'INFO' ('Install dir: {0}' -f $InstallDir)
    Remove-OpenOnlyRegistry
    Remove-InstallDirectory
    Refresh-Shell
    Write-Log 'OK' 'Uninstallation completed successfully.'
    exit 0
}
catch {
    Write-Log 'ERROR' $_.Exception.Message
    if ($_.ScriptStackTrace) { Write-Log 'ERROR' $_.ScriptStackTrace }
    exit 1
}
