param(
    [Parameter(Mandatory=$true)]
    [string]$PackageRoot
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$Version = 'V1'
$AppSourceDir = Join-Path $PackageRoot 'app'
if (-not (Test-Path -LiteralPath $AppSourceDir)) {
    $AppSourceDir = Join-Path $PackageRoot '_publish\GDBPreviewer'
}

$InstallDir = Join-Path $env:LOCALAPPDATA 'Programs\GDBPreviewer'
$LogPath = Join-Path $env:TEMP 'GDBPreviewer_install.log'

$GdbVerb = 'GdbPreviewer'
$GdbProgId = 'GDBPreviewer.FileGeodatabase'
$LegacyProgId = 'ESRI.GDB.Database'
$GdbNameFilter = 'System.FileName:"*.gdb"'
$StateRoot = 'Software\GDB Previewer'
$BackupRoot = 'Software\GDB Previewer\Backup'
$DoubleClickVerb = 'GdbDoubleClickRouter'
$PreviewHandlerIid = '{8895b1c6-b41f-4c1c-a562-0d564250836f}'
$IExtractIconIid = '{000214FA-0000-0000-C000-000000000046}'
$PreviewHandlerClsid = '{7A4C1B2E-8D3F-4B9A-9E5C-0F1A2B3C4D5E}'
$IconHandlerClsid = '{A1B2C3D4-E5F6-7890-ABCD-EF1234567890}'

function Write-Log {
    param([string]$Level, [string]$Message)
    $line = '[{0}] {1}' -f $Level, $Message
    Write-Host $line
    $stamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'
    Add-Content -LiteralPath $LogPath -Value ('[{0}] [{1}] {2}' -f $stamp, $Level, $Message) -Encoding UTF8
}

function Write-Step {
    param([string]$Message)
    Write-Host ''
    Write-Log 'STEP' $Message
}

function Set-RegDefault {
    param([Microsoft.Win32.RegistryKey]$Root, [string]$SubKey, [string]$Value)
    $k = $Root.CreateSubKey($SubKey)
    try { $k.SetValue('', [string]$Value, [Microsoft.Win32.RegistryValueKind]::String) }
    finally { if ($k) { $k.Close() } }
}

function Set-RegValue {
    param([Microsoft.Win32.RegistryKey]$Root, [string]$SubKey, [string]$Name, [string]$Value)
    $k = $Root.CreateSubKey($SubKey)
    try { $k.SetValue($Name, [string]$Value, [Microsoft.Win32.RegistryValueKind]::String) }
    finally { if ($k) { $k.Close() } }
}

function Remove-RegTreeSafe {
    param([Microsoft.Win32.RegistryKey]$Root, [string]$SubKey)
    try { $Root.DeleteSubKeyTree($SubKey, $false) } catch { }
}

function Remove-RegValueSafe {
    param([Microsoft.Win32.RegistryKey]$Root, [string]$SubKey, [string]$Name)
    $k = $Root.OpenSubKey($SubKey, $true)
    if ($k) { try { $k.DeleteValue($Name, $false) } finally { $k.Close() } }
}

function Get-RegValueInfo {
    param([Microsoft.Win32.RegistryKey]$Root, [string]$SubKey, [string]$Name)
    $result = @{ KeyExists=$false; ValueExists=$false; Value=$null; Kind='' }
    $k = $Root.OpenSubKey($SubKey, $false)
    if ($k) {
        try {
            $result.KeyExists = $true
            $names = @($k.GetValueNames())
            if ($names -contains $Name) {
                $result.ValueExists = $true
                $result.Value = $k.GetValue($Name, $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
                try { $result.Kind = [string]$k.GetValueKind($Name) } catch { $result.Kind = '' }
            }
        }
        finally { $k.Close() }
    }
    return $result
}

function Get-BackupValue {
    param([string]$Name, [string]$DefaultValue)
    $k = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($BackupRoot, $false)
    if (-not $k) { return $DefaultValue }
    try {
        $v = $k.GetValue($Name, $null)
        if ($null -eq $v) { return $DefaultValue }
        return [string]$v
    }
    finally { $k.Close() }
}

function Save-BackupRegValue {
    param(
        [string]$Id,
        [Microsoft.Win32.RegistryKey]$Root,
        [string]$SubKey,
        [string]$Name,
        [string]$OurExpectedValue
    )
    $info = Get-RegValueInfo -Root $Root -SubKey $SubKey -Name $Name
    $exists = '0'; $value = ''; $kind = ''; $wasOurs = '0'
    if ($info.ValueExists) {
        $currentText = [string]$info.Value
        if ($currentText -eq $OurExpectedValue) { $wasOurs = '1' }
        else { $exists = '1'; $value = $currentText; $kind = [string]$info.Kind }
    }
    Set-RegValue ([Microsoft.Win32.Registry]::CurrentUser) $BackupRoot ($Id + '_Exists') $exists
    Set-RegValue ([Microsoft.Win32.Registry]::CurrentUser) $BackupRoot ($Id + '_Value') $value
    Set-RegValue ([Microsoft.Win32.Registry]::CurrentUser) $BackupRoot ($Id + '_Kind') $kind
    Set-RegValue ([Microsoft.Win32.Registry]::CurrentUser) $BackupRoot ($Id + '_WasOurs') $wasOurs
}

function Initialize-RegistryBackup {
    Write-Step 'Create registry safety backup'
    $complete = Get-BackupValue -Name 'BackupComplete' -DefaultValue '0'
    if ($complete -eq '1') {
        Write-Log 'INFO' 'Existing registry backup found; keeping it for safe reinstall.'
        return
    }
    Remove-RegTreeSafe ([Microsoft.Win32.Registry]::CurrentUser) $BackupRoot
    Set-RegValue ([Microsoft.Win32.Registry]::CurrentUser) $BackupRoot 'BackupSchema' $Version
    Set-RegValue ([Microsoft.Win32.Registry]::CurrentUser) $BackupRoot 'CreatedAt' (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
    Save-BackupRegValue -Id 'DotGdb_Default' -Root ([Microsoft.Win32.Registry]::CurrentUser) -SubKey 'Software\Classes\.gdb' -Name '' -OurExpectedValue $GdbProgId
    Save-BackupRegValue -Id 'DotGdb_PerceivedType' -Root ([Microsoft.Win32.Registry]::CurrentUser) -SubKey 'Software\Classes\.gdb' -Name 'PerceivedType' -OurExpectedValue 'document'
    Save-BackupRegValue -Id 'DotGdb_ContentType' -Root ([Microsoft.Win32.Registry]::CurrentUser) -SubKey 'Software\Classes\.gdb' -Name 'Content Type' -OurExpectedValue 'application/x-filegdb'
    Save-BackupRegValue -Id 'DotGdb_AlwaysShowExt' -Root ([Microsoft.Win32.Registry]::CurrentUser) -SubKey 'Software\Classes\.gdb' -Name 'AlwaysShowExt' -OurExpectedValue ''
    Set-RegValue ([Microsoft.Win32.Registry]::CurrentUser) $BackupRoot 'BackupComplete' '1'
    Write-Log 'OK' 'Registry backup created under HKCU\Software\GDB Previewer\Backup.'
}

function Remove-ZoneIdentifierSafe {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { return }
    try { Unblock-File -LiteralPath $Path -ErrorAction SilentlyContinue } catch { }
    try { Remove-Item -LiteralPath $Path -Stream Zone.Identifier -Force -ErrorAction SilentlyContinue } catch { }
}

function Unblock-PathTree {
    param([string]$Path, [string]$Label)
    Write-Step ('Remove Windows downloaded-file security marks: ' + $Label)
    if (-not (Test-Path -LiteralPath $Path)) { Write-Log 'WARN' ('Skip unblock; path not found: {0}' -f $Path); return }
    Remove-ZoneIdentifierSafe -Path $Path
    $count = 0
    try {
        foreach ($item in Get-ChildItem -LiteralPath $Path -Recurse -Force -ErrorAction SilentlyContinue) {
            Remove-ZoneIdentifierSafe -Path $item.FullName
            $count++
        }
    } catch { Write-Log 'WARN' ('Unable to enumerate path for unblock: {0}' -f $_.Exception.Message) }
    Write-Log 'OK' ('Unblock pass completed for {0}; scanned items: {1}' -f $Path, $count)
}

function Refresh-Shell {
    Write-Step 'Refresh Shell cache'
    $ie4 = Join-Path $env:windir 'System32\ie4uinit.exe'
    if (Test-Path -LiteralPath $ie4) {
        try { Start-Process -FilePath $ie4 -ArgumentList '-ClearIconCache' -Wait -WindowStyle Hidden -ErrorAction SilentlyContinue | Out-Null } catch { }
        try { Start-Process -FilePath $ie4 -ArgumentList '-show' -Wait -WindowStyle Hidden -ErrorAction SilentlyContinue | Out-Null } catch { }
    }
    try {
        Add-Type -Namespace Win32 -Name ShellNotify -MemberDefinition '[System.Runtime.InteropServices.DllImport("shell32.dll")] public static extern void SHChangeNotify(int wEventId, uint uFlags, System.IntPtr dwItem1, System.IntPtr dwItem2);' -ErrorAction SilentlyContinue
        [Win32.ShellNotify]::SHChangeNotify(0x08000000, 0, [IntPtr]::Zero, [IntPtr]::Zero)
    } catch { }
    Write-Log 'OK' 'Shell refresh requested.'
}

function Cleanup-LegacyUserRegistry {
    Write-Step 'Remove legacy user-level Preview Pane / icon hooks if present'
    Remove-RegTreeSafe ([Microsoft.Win32.Registry]::CurrentUser) ('Software\Classes\Directory\ShellEx\' + $PreviewHandlerIid)
    Remove-RegTreeSafe ([Microsoft.Win32.Registry]::CurrentUser) ('Software\Classes\.gdb\ShellEx\' + $PreviewHandlerIid)
    Remove-RegTreeSafe ([Microsoft.Win32.Registry]::CurrentUser) ('Software\Classes\' + $LegacyProgId + '\ShellEx\' + $PreviewHandlerIid)
    Remove-RegTreeSafe ([Microsoft.Win32.Registry]::CurrentUser) ('Software\Classes\' + $GdbProgId + '\ShellEx\' + $PreviewHandlerIid)
    Remove-RegTreeSafe ([Microsoft.Win32.Registry]::CurrentUser) ('Software\Classes\Directory\shell\' + $DoubleClickVerb)
    Remove-RegValueSafe ([Microsoft.Win32.Registry]::CurrentUser) ('Software\Classes\Directory\ShellEx\' + $IExtractIconIid) ''
    Remove-RegValueSafe ([Microsoft.Win32.Registry]::CurrentUser) ('Software\Classes\.gdb\ShellEx\' + $IExtractIconIid) ''
    Write-Log 'OK' 'Legacy user-level hooks removed or skipped.'
}

function Deploy-App {
    Write-Step 'Deploy application to user profile'
    $exe = Join-Path $AppSourceDir 'GDBPreviewer.exe'
    $dll = Join-Path $AppSourceDir 'FileGDB.Core.dll'
    if (-not (Test-Path -LiteralPath $exe)) { throw ('Missing GDBPreviewer.exe in app source: {0}' -f $AppSourceDir) }
    if (-not (Test-Path -LiteralPath $dll)) { throw ('Missing FileGDB.Core.dll in app source: {0}' -f $AppSourceDir) }
    if (Test-Path -LiteralPath $InstallDir) {
        Remove-Item -LiteralPath $InstallDir -Recurse -Force -ErrorAction SilentlyContinue
        Start-Sleep -Milliseconds 500
    }
    New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
    Copy-Item -Path (Join-Path $AppSourceDir '*') -Destination $InstallDir -Recurse -Force
    Write-Log 'OK' ('Deployed to: {0}' -f $InstallDir)
}

function Write-RouterScript {
    Write-Step 'Write .gdb folder open router'
    $routerPath = Join-Path $InstallDir 'GdbFolderRouter.vbs'
    $router = @'
Option Explicit
Dim shell, fso, target, installDir, appPath
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
target = ""
If WScript.Arguments.Count >= 1 Then target = WScript.Arguments(0)
If target = "" And WScript.Arguments.Count >= 2 Then target = WScript.Arguments(1)
If target = "" Then WScript.Quit 1
If LCase(Right(target, 4)) = ".gdb" And fso.FolderExists(target) Then
    installDir = fso.GetParentFolderName(WScript.ScriptFullName)
    appPath = installDir & "\GDBPreviewer.exe"
    shell.Run Chr(34) & appPath & Chr(34) & " " & Chr(34) & target & Chr(34), 1, False
Else
    shell.Run "explorer.exe " & Chr(34) & target & Chr(34), 1, False
End If
'@
    Set-Content -LiteralPath $routerPath -Value $router -Encoding ASCII
    Write-Log 'OK' ('Router written: {0}' -f $routerPath)
}

function Write-InstallStateFile {
    Write-Step 'Write install state file'
    $statePath = Join-Path $InstallDir 'install_state.txt'
    $lines = @(
        'GDB Previewer install state',
        ('Version=' + $Version),
        ('InstallDir=' + $InstallDir),
        ('InstalledAt=' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')),
        'InstallScope=user',
        'IntegrationMode=gdb-open-only',
        'PreviewPane=disabled',
        'RegistryBackup=HKCU\Software\GDB Previewer\Backup'
    )
    Set-Content -LiteralPath $statePath -Value $lines -Encoding UTF8
    Write-Log 'OK' ('Install state written: {0}' -f $statePath)
}

function Write-OpenOnlyRegistry {
    Write-Step 'Write user-level .gdb association and context menu registry'
    Set-RegValue ([Microsoft.Win32.Registry]::CurrentUser) $StateRoot 'InstallPath' $InstallDir
    Set-RegValue ([Microsoft.Win32.Registry]::CurrentUser) $StateRoot 'Version' $Version
    Set-RegValue ([Microsoft.Win32.Registry]::CurrentUser) $StateRoot 'InstallScope' 'user'
    Set-RegValue ([Microsoft.Win32.Registry]::CurrentUser) $StateRoot 'IntegrationMode' 'gdb-open-only'
    Set-RegValue ([Microsoft.Win32.Registry]::CurrentUser) $StateRoot 'Owner' 'GDBPreviewer'

    $appPath = Join-Path $InstallDir 'GDBPreviewer.exe'
    $wscript = Join-Path $env:windir 'System32\wscript.exe'
    $router = Join-Path $InstallDir 'GdbFolderRouter.vbs'
    $routerCommand = '"{0}" "{1}" "%1" "%V"' -f $wscript, $router

    Set-RegDefault ([Microsoft.Win32.Registry]::CurrentUser) 'Software\Classes\.gdb' $GdbProgId
    Set-RegValue ([Microsoft.Win32.Registry]::CurrentUser) 'Software\Classes\.gdb' 'PerceivedType' 'document'
    Set-RegValue ([Microsoft.Win32.Registry]::CurrentUser) 'Software\Classes\.gdb' 'Content Type' 'application/x-filegdb'
    Set-RegValue ([Microsoft.Win32.Registry]::CurrentUser) 'Software\Classes\.gdb' 'AlwaysShowExt' ''
    Set-RegValue ([Microsoft.Win32.Registry]::CurrentUser) 'Software\Classes\.gdb\OpenWithProgids' $GdbProgId ''

    Remove-RegTreeSafe ([Microsoft.Win32.Registry]::CurrentUser) ('Software\Classes\' + $GdbProgId)
    Set-RegDefault ([Microsoft.Win32.Registry]::CurrentUser) ('Software\Classes\' + $GdbProgId) 'File Geodatabase'
    Set-RegValue ([Microsoft.Win32.Registry]::CurrentUser) ('Software\Classes\' + $GdbProgId) 'GDBPreviewerOwner' '1'
    Set-RegValue ([Microsoft.Win32.Registry]::CurrentUser) ('Software\Classes\' + $GdbProgId) 'Version' $Version
    Set-RegDefault ([Microsoft.Win32.Registry]::CurrentUser) ('Software\Classes\' + $GdbProgId + '\shell') 'open'
    Set-RegDefault ([Microsoft.Win32.Registry]::CurrentUser) ('Software\Classes\' + $GdbProgId + '\shell\open\command') ('"{0}" "%1"' -f $appPath)

    Remove-RegTreeSafe ([Microsoft.Win32.Registry]::CurrentUser) ('Software\Classes\Directory\shell\' + $GdbVerb)
    Set-RegDefault ([Microsoft.Win32.Registry]::CurrentUser) ('Software\Classes\Directory\shell\' + $GdbVerb) '用GDB Previewer打开'
    Set-RegValue ([Microsoft.Win32.Registry]::CurrentUser) ('Software\Classes\Directory\shell\' + $GdbVerb) 'AppliesTo' $GdbNameFilter
    Set-RegValue ([Microsoft.Win32.Registry]::CurrentUser) ('Software\Classes\Directory\shell\' + $GdbVerb) 'DefaultAppliesTo' $GdbNameFilter
    Set-RegValue ([Microsoft.Win32.Registry]::CurrentUser) ('Software\Classes\Directory\shell\' + $GdbVerb) 'MUIVerb' '用GDB Previewer打开'
    Set-RegValue ([Microsoft.Win32.Registry]::CurrentUser) ('Software\Classes\Directory\shell\' + $GdbVerb) 'MultiSelectModel' 'Single'
    Set-RegValue ([Microsoft.Win32.Registry]::CurrentUser) ('Software\Classes\Directory\shell\' + $GdbVerb) 'GDBPreviewerOwner' '1'
    Set-RegValue ([Microsoft.Win32.Registry]::CurrentUser) ('Software\Classes\Directory\shell\' + $GdbVerb) 'Version' $Version
    Set-RegDefault ([Microsoft.Win32.Registry]::CurrentUser) ('Software\Classes\Directory\shell\' + $GdbVerb + '\command') $routerCommand

    Remove-RegTreeSafe ([Microsoft.Win32.Registry]::CurrentUser) ('Software\Classes\Directory\shell\' + $DoubleClickVerb)
    Remove-RegTreeSafe ([Microsoft.Win32.Registry]::CurrentUser) ('Software\Classes\' + $LegacyProgId + '\shell\preview')
    Remove-RegTreeSafe ([Microsoft.Win32.Registry]::CurrentUser) ('Software\Classes\' + $GdbProgId + '\shell\preview')
    Write-Log 'OK' 'Open-only registry updated under HKCU.'
}

function Validate-Install {
    Write-Step 'Validate installation'
    $appPath = Join-Path $InstallDir 'GDBPreviewer.exe'
    $router = Join-Path $InstallDir 'GdbFolderRouter.vbs'
    if (-not (Test-Path -LiteralPath $appPath)) { throw ('Missing installed app: {0}' -f $appPath) }
    if (-not (Test-Path -LiteralPath $router)) { throw ('Missing router script: {0}' -f $router) }
    $ext = Get-RegValueInfo -Root ([Microsoft.Win32.Registry]::CurrentUser) -SubKey 'Software\Classes\.gdb' -Name ''
    if (-not $ext.ValueExists -or ([string]$ext.Value -ne $GdbProgId)) { throw '.gdb HKCU association was not written correctly.' }
    $verbOwner = Get-RegValueInfo -Root ([Microsoft.Win32.Registry]::CurrentUser) -SubKey ('Software\Classes\Directory\shell\' + $GdbVerb) -Name 'GDBPreviewerOwner'
    if (-not $verbOwner.ValueExists -or ([string]$verbOwner.Value -ne '1')) { throw 'Directory context menu owner marker was not written correctly.' }
    Write-Log 'OK' 'Validation passed.'
}

try {
    if (Test-Path -LiteralPath $LogPath) { Remove-Item -LiteralPath $LogPath -Force -ErrorAction SilentlyContinue }
    Write-Log 'INFO' ('GDB Previewer installer {0}' -f $Version)
    Write-Log 'INFO' ('Package root: {0}' -f $PackageRoot)
    Write-Log 'INFO' ('Install dir: {0}' -f $InstallDir)
    Unblock-PathTree -Path $PackageRoot -Label 'package root'
    Initialize-RegistryBackup
    Cleanup-LegacyUserRegistry
    Deploy-App
    Unblock-PathTree -Path $InstallDir -Label 'installed application'
    Write-RouterScript
    Unblock-PathTree -Path $InstallDir -Label 'installed router and application'
    Write-InstallStateFile
    Write-OpenOnlyRegistry
    Validate-Install
    Refresh-Shell
    Write-Log 'OK' 'Installation completed successfully. Scope: current user. Enabled: double-click / right-click open .gdb only. Preview Pane remains disabled.'
    exit 0
}
catch {
    Write-Log 'ERROR' $_.Exception.Message
    if ($_.ScriptStackTrace) { Write-Log 'ERROR' $_.ScriptStackTrace }
    exit 1
}
